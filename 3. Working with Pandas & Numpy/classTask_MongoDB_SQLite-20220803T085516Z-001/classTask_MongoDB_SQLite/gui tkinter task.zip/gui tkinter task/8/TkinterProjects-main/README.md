# TkinterProjects
TkinterProjects
1. # Digital Clock using Tkinter
![image](https://user-images.githubusercontent.com/85541665/159933136-09f8efae-3077-44e9-be66-6da8c6172e40.png)


2. # Age Calculator Tool using Tkinter
![image](https://user-images.githubusercontent.com/85541665/159932128-09b6c3ba-63a0-44ac-b724-fcd52edfa31a.png)

3. # Weight Converting Tool using Tkinter
![image](https://user-images.githubusercontent.com/85541665/159934574-c701b65e-5f1b-4be5-8ee2-4c217ba0c762.png)

4. # Simple Calculator using Tkinter
![image](https://user-images.githubusercontent.com/85541665/159934824-29c43981-3c98-4637-b7dd-85b13d609bc5.png)

5. # File Explorer using Tkinter
![image](https://user-images.githubusercontent.com/85541665/159935396-f8668edd-f707-4635-89e0-cafef463e80e.png)

6. # Creating Notepad using Tkinter
![image](https://user-images.githubusercontent.com/85541665/159938575-7a981293-b7a1-46f9-ab7b-cfa74d78120f.png)
