Python Session 9 - Function, lambda function, Iterator, Iterable, generator, yield operator, file-system and OS
