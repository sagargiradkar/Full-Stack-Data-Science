## This is my first module

print("My first module inside Custom_Module1")
