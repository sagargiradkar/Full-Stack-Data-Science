def fn11():
    print("This is function-1 inside Mod1")
    
def fn12():
    print("This is function-2 inside Mod1")
    
def fn13():
    print("This is function-3 inside Mod1")