def fn21():
    print("This is function-1 inside Mod2")
    
def fn22():
    print("This is function-2 inside Mod2")
