def addition(a, b):
    '''
    Function to return the addition of 2 numbers
    '''
    return a+b